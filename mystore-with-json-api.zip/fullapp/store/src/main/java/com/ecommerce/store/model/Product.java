package com.ecommerce.store.model;

import jakarta.persistence.*;

/**
 * ENTITY — Product
 *
 * An @Entity class maps directly to a database TABLE.
 * Each field becomes a COLUMN in the H2 database.
 *
 * Think of it like this:
 *   Java Class  →  Database Table
 *   Field       →  Column
 *   Object      →  Row (one record)
 *
 * @Table(name="products") names the table "products" in H2.
 * @Id marks the primary key (unique identifier for each row).
 * @GeneratedValue means H2 auto-increments the ID: 1, 2, 3...
 */
@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;          // Auto-generated: 1, 2, 3...

    private String name;       // Product title
    private String description;// Full description text
    private double price;      // Retail price
    private int stock;         // Units available
    private String imageUrl;   // Path to image e.g. /images/headphones.jpg
    private String category;   // "Electronics", "Apparel", "Accessories"

    // Default constructor — required by JPA
    public Product() {}

    // Convenience constructor used by DataSeeder
    public Product(String name, String description, double price,
                   int stock, String imageUrl, String category) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.stock = stock;
        this.imageUrl = imageUrl;
        this.category = category;
    }

    // Getters & Setters — JPA and Jackson (JSON converter) need these
    public Long getId()                      { return id; }
    public String getName()                  { return name; }
    public void setName(String name)         { this.name = name; }
    public String getDescription()           { return description; }
    public void setDescription(String d)     { this.description = d; }
    public double getPrice()                 { return price; }
    public void setPrice(double price)       { this.price = price; }
    public int getStock()                    { return stock; }
    public void setStock(int stock)          { this.stock = stock; }
    public String getImageUrl()              { return imageUrl; }
    public void setImageUrl(String url)      { this.imageUrl = url; }
    public String getCategory()              { return category; }
    public void setCategory(String cat)      { this.category = cat; }
}
