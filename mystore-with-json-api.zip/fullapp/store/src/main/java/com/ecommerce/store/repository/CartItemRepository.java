package com.ecommerce.store.repository;

import com.ecommerce.store.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * REPOSITORY — CartItemRepository
 *
 * Same pattern as ProductRepository.
 * Manages the "cart_items" table in H2.
 *
 * Key operations used:
 *   repo.findAll()     → get all items in cart
 *   repo.save(item)    → add or update a cart item
 *   repo.deleteById()  → remove one item
 *   repo.deleteAll()   → clear entire cart (used after checkout)
 */
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
}
