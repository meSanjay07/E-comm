package com.ecommerce.store.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * ENTITY — Order
 *
 * Represents a completed purchase. Stored in H2 table "orders".
 *
 * When a customer clicks "Place Order":
 *   1. This Order object is saved to the database
 *   2. The entire cart is cleared
 *   3. The order ID is returned to show on the confirmation screen
 *
 * Security note: We NEVER store the full card number.
 * Only the last 4 digits are kept (masked in OrderController).
 */
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;
    private String email;
    private String address;
    private String city;
    private String zipCode;
    private String cardNumber;    // Stored as "****-****-****-1234"
    private double totalAmount;

    @Column(name = "placed_at")
    private LocalDateTime placedAt;  // Timestamp of when order was placed

    public Order() {}

    public Order(String fullName, String email, String address,
                 String city, String zipCode, String cardNumber, double totalAmount) {
        this.fullName = fullName;
        this.email = email;
        this.address = address;
        this.city = city;
        this.zipCode = zipCode;
        this.cardNumber = cardNumber;
        this.totalAmount = totalAmount;
        this.placedAt = LocalDateTime.now();
    }

    public Long getId()                         { return id; }
    public String getFullName()                 { return fullName; }
    public void setFullName(String n)           { this.fullName = n; }
    public String getEmail()                    { return email; }
    public void setEmail(String e)              { this.email = e; }
    public String getAddress()                  { return address; }
    public void setAddress(String a)            { this.address = a; }
    public String getCity()                     { return city; }
    public void setCity(String c)               { this.city = c; }
    public String getZipCode()                  { return zipCode; }
    public void setZipCode(String z)            { this.zipCode = z; }
    public String getCardNumber()               { return cardNumber; }
    public void setCardNumber(String c)         { this.cardNumber = c; }
    public double getTotalAmount()              { return totalAmount; }
    public void setTotalAmount(double t)        { this.totalAmount = t; }
    public LocalDateTime getPlacedAt()          { return placedAt; }
    public void setPlacedAt(LocalDateTime t)    { this.placedAt = t; }
}
