package com.ecommerce.store.controller;

import com.ecommerce.store.model.Order;
import com.ecommerce.store.repository.CartItemRepository;
import com.ecommerce.store.repository.OrderRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST CONTROLLER — OrderController
 *
 * Handles the final step of checkout: placing the order.
 *
 * ENDPOINT:
 *   POST /api/orders  → save order to DB, clear cart, return confirmation
 *
 * WHAT HAPPENS WHEN ORDER IS PLACED:
 *   1. React sends the checkout form data as JSON
 *   2. We mask the card number (security — never store full card!)
 *   3. We save the Order to H2 (gets an auto-generated order ID)
 *   4. We clear all items from cart_items table
 *   5. We return the saved Order (with its new ID) to React
 *   6. React shows the confirmation screen with Order #ID
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderRepository orderRepo;
    private final CartItemRepository cartRepo;

    public OrderController(OrderRepository orderRepo, CartItemRepository cartRepo) {
        this.orderRepo = orderRepo;
        this.cartRepo = cartRepo;
    }

    @PostMapping
    public ResponseEntity<Order> placeOrder(@RequestBody Order order) {
        // SECURITY: Mask card number — store only last 4 digits
        String card = order.getCardNumber();
        if (card != null && card.replaceAll("\\s", "").length() >= 4) {
            String digits = card.replaceAll("\\s", "");
            order.setCardNumber("****-****-****-" + digits.substring(digits.length() - 4));
        }

        // Save order → H2 assigns it an auto-increment ID
        Order savedOrder = orderRepo.save(order);

        // Clear the cart after successful order
        cartRepo.deleteAll();

        // Return the saved order with its new ID to React
        return ResponseEntity.ok(savedOrder);
    }
}
