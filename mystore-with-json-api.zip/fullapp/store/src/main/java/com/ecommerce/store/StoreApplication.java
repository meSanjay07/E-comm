package com.ecommerce.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ENTRY POINT — This is the first class Java runs.
 *
 * @SpringBootApplication is a shortcut annotation that enables:
 *   1. @Configuration      — marks this as a config source
 *   2. @EnableAutoConfiguration — Spring Boot auto-configures H2, JPA, Web etc.
 *   3. @ComponentScan      — scans all classes in this package for @Component,
 *                            @Service, @RestController, @Repository etc.
 *
 * SpringApplication.run() boots the embedded Tomcat server on port 8080.
 */
@SpringBootApplication
public class StoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(StoreApplication.class, args);
    }
}
