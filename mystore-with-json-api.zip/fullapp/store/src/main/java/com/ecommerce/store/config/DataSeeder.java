package com.ecommerce.store.config;

import com.ecommerce.store.model.Product;
import com.ecommerce.store.repository.ProductRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

/**
 * DATA SEEDER — Reads products.json and inserts them into H2 on startup.
 *
 * HOW IT WORKS:
 * 1. Spring Boot sees @Component and creates this class automatically.
 * 2. CommandLineRunner means Spring calls run() once after startup.
 * 3. We use Jackson's ObjectMapper to read the JSON file and convert
 *    each JSON object into a Java Product object (deserialization).
 * 4. We then save all products to H2 via the repository.
 *
 * WHY JSON instead of hardcoding?
 * - Easy to edit product data without touching Java code
 * - Product managers / non-developers can update products.json directly
 * - Clean separation of data from business logic
 *
 * FILE LOCATION:
 *   src/main/resources/products.json
 *   ClassPathResource("products.json") finds it on the classpath at runtime.
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private final ProductRepository productRepository;
    private final ObjectMapper objectMapper;  // Jackson JSON parser

    // Constructor injection — Spring automatically provides these dependencies
    public DataSeeder(ProductRepository productRepository, ObjectMapper objectMapper) {
        this.productRepository = productRepository;
        this.objectMapper = objectMapper;
    }

    @Override
    public void run(String... args) throws Exception {
        // Only seed if the table is empty (prevents duplicate data on restart)
        if (productRepository.count() == 0) {
            // Load products.json from src/main/resources/
            InputStream inputStream = new ClassPathResource("products.json").getInputStream();

            // Jackson reads the JSON array and converts to List<Product>
            // TypeReference<List<Product>> tells Jackson the exact Java type to create
            List<Product> products = objectMapper.readValue(
                inputStream,
                new TypeReference<List<Product>>() {}
            );

            // Save all products to H2 database in one batch
            productRepository.saveAll(products);

            System.out.println("✅ Seeded " + products.size() + " products from products.json");
        }
    }
}
