package com.ecommerce.store.model;

import jakarta.persistence.*;

/**
 * ENTITY — CartItem
 *
 * Represents one line in the shopping cart.
 * Stored in H2 table "cart_items".
 *
 * Why not just use Product?
 * Because a CartItem needs a QUANTITY field and tracks which
 * product was added — it's a separate concept from the product itself.
 *
 * Relationship:
 *   CartItem.productId  →  links back to Product.id
 *   (we store a copy of name/price/imageUrl so even if the product
 *    changes price, the cart still shows what the user saw)
 */
@Entity
@Table(name = "cart_items")
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long productId;   // Which product this refers to
    private String name;       // Snapshot of product name at time of adding
    private double price;      // Snapshot of price at time of adding
    private String imageUrl;   // Snapshot of image
    private int quantity;      // How many units in cart

    public CartItem() {}

    public CartItem(Long productId, String name, double price, String imageUrl, int quantity) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
        this.quantity = quantity;
    }

    public Long getId()                        { return id; }
    public Long getProductId()                 { return productId; }
    public void setProductId(Long productId)   { this.productId = productId; }
    public String getName()                    { return name; }
    public void setName(String name)           { this.name = name; }
    public double getPrice()                   { return price; }
    public void setPrice(double price)         { this.price = price; }
    public String getImageUrl()                { return imageUrl; }
    public void setImageUrl(String url)        { this.imageUrl = url; }
    public int getQuantity()                   { return quantity; }
    public void setQuantity(int quantity)      { this.quantity = quantity; }
}
