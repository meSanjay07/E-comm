package com.ecommerce.store.repository;

import com.ecommerce.store.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * REPOSITORY — OrderRepository
 *
 * Manages the "orders" table in H2.
 * Used only to save a new order after checkout.
 */
public interface OrderRepository extends JpaRepository<Order, Long> {
}
