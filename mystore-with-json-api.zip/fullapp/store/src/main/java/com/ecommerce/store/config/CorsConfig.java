package com.ecommerce.store.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

/**
 * CORS CONFIGURATION — Cross-Origin Resource Sharing
 *
 * WHAT IS CORS?
 * Browsers have a security rule: a webpage can only make API calls
 * to the SAME origin (same domain + port) it was loaded from.
 *
 * OUR PROBLEM:
 *   React frontend runs on → http://localhost:3000
 *   Spring Boot runs on    → http://localhost:8080
 *   These are DIFFERENT origins (different ports!)
 *
 * Without this config, the browser would BLOCK React's fetch() calls
 * to Spring Boot with a CORS error.
 *
 * THIS CONFIG tells Spring Boot:
 *   "It's OK to accept requests from http://localhost:3000"
 *   "Allow GET, POST, PUT, DELETE methods"
 *
 * In production you'd replace localhost:3000 with your real domain.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")           // Apply to all /api/ routes
                .allowedOrigins("http://localhost:3000")  // React dev server
                .allowedMethods("GET", "POST", "PUT", "DELETE")
                .allowedHeaders("*");
    }
}
