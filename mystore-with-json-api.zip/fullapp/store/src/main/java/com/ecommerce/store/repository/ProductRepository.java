package com.ecommerce.store.repository;

import com.ecommerce.store.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * REPOSITORY — ProductRepository
 *
 * This interface gives us FREE database operations without writing any SQL.
 * Spring Data JPA auto-generates the implementation at runtime.
 *
 * By extending JpaRepository<Product, Long> we get:
 *   repo.findAll()        → SELECT * FROM products
 *   repo.findById(id)     → SELECT * FROM products WHERE id = ?
 *   repo.save(product)    → INSERT or UPDATE
 *   repo.deleteById(id)   → DELETE FROM products WHERE id = ?
 *   repo.count()          → SELECT COUNT(*) FROM products
 *
 * The two generic types mean:
 *   Product  → which entity/table this repo manages
 *   Long     → the data type of the primary key (id)
 *
 * We don't need any custom methods right now, so the body is empty.
 */
public interface ProductRepository extends JpaRepository<Product, Long> {
}
