package com.ecommerce.store.controller;

import com.ecommerce.store.model.CartItem;
import com.ecommerce.store.repository.CartItemRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST CONTROLLER — CartController
 *
 * Manages the shopping cart stored in H2.
 *
 * ENDPOINTS:
 *   GET    /api/cart         → fetch all items in cart
 *   POST   /api/cart         → add item (auto-increments qty if already exists)
 *   PUT    /api/cart/{id}    → update quantity of one item
 *   DELETE /api/cart/{id}    → remove one item
 *   DELETE /api/cart         → clear entire cart
 *
 * WHY BACKEND CART (not just React state)?
 *   - Cart persists if you refresh the page
 *   - Cart persists if you open a new browser tab
 *   - Real-world apps need server-side cart for inventory checks
 */
@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartItemRepository repo;

    public CartController(CartItemRepository repo) {
        this.repo = repo;
    }

    /** GET /api/cart — React calls this to load cart on page refresh */
    @GetMapping
    public List<CartItem> getCart() {
        return repo.findAll();
    }

    /**
     * POST /api/cart
     * React sends a CartItem JSON body when user clicks "Add to Cart".
     *
     * SMART LOGIC: If the same product is already in the cart,
     * we INCREMENT quantity instead of adding a duplicate row.
     *
     * @RequestBody — Spring reads the JSON from request body
     * and converts it to a CartItem Java object automatically.
     */
    @PostMapping
    public CartItem addToCart(@RequestBody CartItem item) {
        List<CartItem> existing = repo.findAll();
        for (CartItem c : existing) {
            if (c.getProductId().equals(item.getProductId())) {
                // Product already in cart → just bump the quantity
                c.setQuantity(c.getQuantity() + 1);
                return repo.save(c);
            }
        }
        // New product → set quantity to 1 and save
        item.setQuantity(1);
        return repo.save(item);
    }

    /**
     * PUT /api/cart/{id}
     * Called when user clicks + or − on the Cart page.
     * Updates the quantity of the specific cart row.
     */
    @PutMapping("/{id}")
    public ResponseEntity<CartItem> updateQuantity(
            @PathVariable Long id,
            @RequestBody CartItem updated) {
        return repo.findById(id).map(item -> {
            item.setQuantity(updated.getQuantity());
            return ResponseEntity.ok(repo.save(item));
        }).orElse(ResponseEntity.notFound().build());
    }

    /** DELETE /api/cart/{id} — Remove one specific item from cart */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeItem(@PathVariable Long id) {
        repo.deleteById(id);
        return ResponseEntity.noContent().build(); // HTTP 204 No Content
    }

    /** DELETE /api/cart — Wipe entire cart (called after order is placed) */
    @DeleteMapping
    public ResponseEntity<Void> clearCart() {
        repo.deleteAll();
        return ResponseEntity.noContent().build();
    }
}
