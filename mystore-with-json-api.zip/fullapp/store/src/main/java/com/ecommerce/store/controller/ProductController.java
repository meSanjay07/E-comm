package com.ecommerce.store.controller;

import com.ecommerce.store.model.Product;
import com.ecommerce.store.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST CONTROLLER — ProductController
 *
 * COMPLETE DATA FLOW (products.json → browser):
 *
 *  Step 1 — App starts
 *    DataSeeder reads products.json using Jackson (ObjectMapper)
 *    → Converts each JSON object to a Product Java object
 *    → Calls productRepository.saveAll() to insert rows into H2 table
 *
 *  Step 2 — React app loads (browser opens localhost:3000)
 *    PLP.jsx runs useEffect → calls api.getProducts()
 *    → fetch("http://localhost:8080/api/products")
 *    → HTTP GET request arrives at this controller
 *
 *  Step 3 — getAllProducts() runs
 *    → productService.getAllProducts()
 *    → productRepository.findAll()
 *    → H2 executes: SELECT * FROM products
 *    → Returns List<Product> Java objects
 *    → Spring's Jackson auto-serialises to JSON array
 *    → HTTP 200 response with JSON body sent back
 *
 *  Step 4 — React receives JSON
 *    setProducts(data) stores array in state
 *    React re-renders → product cards appear in the grid
 *
 *  Step 5 — User clicks "View Details"
 *    navigate('/product/3') → URL changes to /product/3
 *    PDP.jsx useEffect runs → fetch(".../api/products/3")
 *    → getProductById(3) runs → SELECT * FROM products WHERE id=3
 *    → Single Product object returned as JSON
 *    → PDP renders full detail view
 */
@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:3000")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    /**
     * GET /api/products
     *
     * Sample JSON response:
     * [
     *   {
     *     "id": 1,
     *     "name": "Wireless Noise-Cancelling Headphones",
     *     "description": "Premium over-ear headphones...",
     *     "price": 149.99,
     *     "stock": 23,
     *     "imageUrl": "https://images.unsplash.com/...",
     *     "category": "Electronics"
     *   },
     *   { ... }
     * ]
     */
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    /**
     * GET /api/products/{id}
     *
     * Example: GET /api/products/2
     * Returns the single product with id=2 or HTTP 404 if not found.
     *
     * Sample JSON response:
     * {
     *   "id": 2,
     *   "name": "Classic White Sneakers",
     *   "description": "Minimalist leather sneakers...",
     *   "price": 89.99,
     *   "stock": 40,
     *   "imageUrl": "https://images.unsplash.com/...",
     *   "category": "Apparel"
     * }
     */
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
