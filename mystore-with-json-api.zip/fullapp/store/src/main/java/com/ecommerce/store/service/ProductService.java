package com.ecommerce.store.service;

import com.ecommerce.store.model.Product;
import com.ecommerce.store.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * SERVICE LAYER — ProductService
 *
 * WHY ADD A SERVICE LAYER?
 * Best practice in Spring Boot is a 3-layer architecture:
 *
 *   Controller  →  Service  →  Repository  →  Database
 *
 * Controller : handles HTTP requests/responses only
 * Service    : holds all business logic
 * Repository : handles database queries only
 *
 * This separation means:
 *   - If business logic changes, you only touch the Service
 *   - If the database changes, you only touch the Repository
 *   - Controllers stay thin and focused on HTTP concerns
 *
 * @Service marks this class so Spring creates and manages it.
 */
@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    /**
     * Fetch all products from H2.
     * Called by ProductController for GET /api/products
     */
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    /**
     * Fetch a single product by its ID.
     * Returns Optional — caller decides what to do if not found.
     * Called by ProductController for GET /api/products/{id}
     */
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }
}
