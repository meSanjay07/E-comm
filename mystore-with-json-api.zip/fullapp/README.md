# MyStore — Full E-Commerce Platform
**Stack:** Java 17 / Spring Boot 3.2 | React 18 | H2 In-Memory DB | JPA

---

## Project Structure
```
fullapp/
├── store/                          ← Spring Boot Backend (port 8080)
│   ├── pom.xml
│   └── src/main/
│       ├── resources/
│       │   ├── application.properties
│       │   └── products.json       ← Product data source
│       └── java/com/ecommerce/store/
│           ├── StoreApplication.java
│           ├── model/
│           │   ├── Product.java
│           │   ├── CartItem.java
│           │   └── Order.java
│           ├── repository/
│           │   ├── ProductRepository.java
│           │   ├── CartItemRepository.java
│           │   └── OrderRepository.java
│           ├── controller/
│           │   ├── ProductController.java
│           │   ├── CartController.java
│           │   └── OrderController.java
│           └── config/
│               ├── DataSeeder.java
│               └── CorsConfig.java
│
└── store-frontend/                 ← React Frontend (port 3000)
    ├── package.json
    └── src/
        ├── index.js
        ├── App.js
        ├── services/
        │   └── api.js              ← All backend API calls
        ├── components/
        │   └── Navbar.jsx
        └── pages/
            ├── PLP.jsx             ← Product Listing Page
            ├── PDP.jsx             ← Product Detail Page
            ├── Cart.jsx            ← Cart with qty controls
            └── Checkout.jsx        ← Form + Confirmation
```

---

## How to Run

### Step 1 — Start the Backend
```bash
cd store
mvn spring-boot:run
```
Server starts at: **http://localhost:8080**

Test endpoints in browser:
- http://localhost:8080/api/products
- http://localhost:8080/api/products/1
- http://localhost:8080/api/cart
- http://localhost:8080/h2-console  (JDBC URL: jdbc:h2:mem:storedb)

### Step 2 — Start the Frontend
```bash
cd store-frontend
npm install
npm start
```
App opens at: **http://localhost:3000**

---

## API Endpoints

| Method | Endpoint             | Description                    |
|--------|----------------------|--------------------------------|
| GET    | /api/products        | Get all products (PLP)         |
| GET    | /api/products/{id}   | Get one product (PDP)          |
| GET    | /api/cart            | Get all cart items             |
| POST   | /api/cart            | Add item to cart               |
| PUT    | /api/cart/{id}       | Update item quantity           |
| DELETE | /api/cart/{id}       | Remove one item                |
| DELETE | /api/cart            | Clear entire cart              |
| POST   | /api/orders          | Place order + clear cart       |

---

## Product Images
Place your own images in:
  `store/src/main/resources/static/images/`

Filenames must match what is in products.json:
  headphones.jpg, sneakers.jpg, bottle.jpg, keyboard.jpg, shirt.jpg

Images are served at: http://localhost:8080/images/filename.jpg
