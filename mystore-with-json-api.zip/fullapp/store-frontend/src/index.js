import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

/**
 * INDEX.JS — React Bootstrap
 *
 * This is the first JS file that runs in the browser.
 * It finds the <div id="root"> in public/index.html
 * and mounts our entire React app inside it.
 *
 * After this runs, React "owns" the DOM and handles
 * all rendering, updates, and navigation.
 */
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
