import { Link, useLocation } from 'react-router-dom';

/**
 * NAVBAR COMPONENT
 *
 * Props received from App.js:
 *   cartCount — total items in cart (number)
 *
 * useLocation() — React Router hook that tells us the current URL path.
 * We use it to highlight the active nav link.
 *
 * Link component — React Router's <a> tag replacement.
 * It navigates WITHOUT a full page reload (Single Page App behaviour).
 * Regular <a href="..."> would reload the entire page.
 *
 * The red badge only renders when cartCount > 0.
 * This is conditional rendering: {cartCount > 0 && <span>...</span>}
 * The && means: "only render the right side if left side is truthy".
 */
function Navbar({ cartCount }) {
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.brand}>
        🛍 MyStore
      </Link>

      <div style={styles.links}>
        <Link to="/" style={{ ...styles.link, ...(isActive('/') ? styles.activeLink : {}) }}>
          Home
        </Link>
        <Link to="/cart" style={{ ...styles.link, ...(isActive('/cart') ? styles.activeLink : {}), ...styles.cartLink }}>
          🛒 Cart
          {cartCount > 0 && (
            <span style={styles.badge}>{cartCount}</span>
          )}
        </Link>
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0 32px',
    height: '60px',
    background: '#1a1a2e',
    position: 'sticky',
    top: 0,
    zIndex: 100,
    boxShadow: '0 2px 12px rgba(0,0,0,0.3)',
  },
  brand: {
    color: '#fff',
    textDecoration: 'none',
    fontSize: '1.25rem',
    fontWeight: 700,
    letterSpacing: '-0.3px',
  },
  links: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  link: {
    color: '#aab4c8',
    textDecoration: 'none',
    padding: '6px 14px',
    borderRadius: '6px',
    fontSize: '0.9rem',
    fontWeight: 500,
    transition: 'color 0.15s',
  },
  activeLink: {
    color: '#fff',
    background: 'rgba(255,255,255,0.08)',
  },
  cartLink: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    color: '#fff',
  },
  badge: {
    background: '#e94560',
    color: '#fff',
    borderRadius: '50%',
    width: '20px',
    height: '20px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '11px',
    fontWeight: 700,
  },
};

export default Navbar;
