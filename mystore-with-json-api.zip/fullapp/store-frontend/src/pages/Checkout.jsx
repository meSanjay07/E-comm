import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../services/api';

/**
 * CHECKOUT PAGE
 * Route: /checkout
 *
 * TWO SCREENS IN ONE COMPONENT:
 *   Screen 1 — Checkout Form   (shown when confirmed === null)
 *   Screen 2 — Order Confirmed (shown when confirmed has an Order object)
 *
 * This is a common React pattern: conditional rendering based on state.
 *   if (confirmed) → show confirmation
 *   else           → show form
 *
 * FORM STATE:
 *   All input fields are "controlled inputs" — their value is
 *   stored in React state (form object) and updated on every keystroke
 *   via handleChange(). React is always the "source of truth".
 *
 * VALIDATION:
 *   validate() checks each field and returns an errors object.
 *   If errors is non-empty, we show messages and stop submission.
 *   This runs entirely in the browser — no backend call needed.
 *
 * ORDER SUBMIT FLOW:
 *   1. validate() — abort if any field is invalid
 *   2. api.placeOrder() — POST to /api/orders
 *   3. Backend: saves Order, masks card, clears cart, returns Order
 *   4. setConfirmed(order) — switches to confirmation screen
 *   5. refreshCartCount() — resets navbar badge to 0
 */
function Checkout({ refreshCartCount }) {
  const [items, setItems]       = useState([]);
  const [confirmed, setConfirmed] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    fullName:   '',
    email:      '',
    address:    '',
    city:       '',
    zipCode:    '',
    cardNumber: '',
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    api.getCart().then(setItems).catch(() => {});
  }, []);

  // ── Pricing ──
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const shipping  = subtotal > 0 ? 9.99 : 0;
  const total     = subtotal + shipping;

  // ── Controlled Input Handler ──
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // Clear that field's error as user types
    setErrors(prev => ({ ...prev, [name]: '' }));
  };

  // ── Client-Side Validation ──
  const validate = () => {
    const e = {};
    if (!form.fullName.trim())
      e.fullName = 'Full name is required.';
    if (!form.email.trim() || !form.email.includes('@'))
      e.email = 'A valid email address is required.';
    if (!form.address.trim())
      e.address = 'Street address is required.';
    if (!form.city.trim())
      e.city = 'City is required.';
    if (!form.zipCode.trim())
      e.zipCode = 'ZIP / Postal code is required.';
    const rawCard = form.cardNumber.replace(/\s|-/g, '');
    if (rawCard.length !== 16 || isNaN(rawCard))
      e.cardNumber = 'Enter a valid 16-digit card number.';
    return e;
  };

  // ── Submit Handler ──
  const handleSubmit = () => {
    const e = validate();
    if (Object.keys(e).length > 0) {
      setErrors(e);
      return;
    }
    if (items.length === 0) {
      navigate('/cart');
      return;
    }
    setSubmitting(true);
    api.placeOrder({ ...form, totalAmount: total })
      .then(order => {
        setConfirmed(order);
        refreshCartCount();
        setSubmitting(false);
      })
      .catch(() => setSubmitting(false));
  };

  // ════════════════════════════════════════════
  // SCREEN 2 — Order Confirmation
  // ════════════════════════════════════════════
  if (confirmed) return (
    <div style={styles.confirmPage}>
      <div style={styles.confirmCard}>
        <div style={styles.checkCircle}>✓</div>
        <h2 style={styles.confirmTitle}>Order Confirmed!</h2>
        <p style={styles.confirmSub}>
          Thank you, <strong>{confirmed.fullName}</strong>!<br />
          A confirmation will be sent to <strong>{confirmed.email}</strong>.
        </p>

        <div style={styles.confirmDetails}>
          {[
            ['Order ID',   `#${confirmed.id}`],
            ['Total Paid', `$${confirmed.totalAmount.toFixed(2)}`],
            ['Card',       confirmed.cardNumber],
            ['Shipping to', `${confirmed.address}, ${confirmed.city} ${confirmed.zipCode}`],
          ].map(([label, value]) => (
            <div key={label} style={styles.confirmRow}>
              <span style={styles.confirmLabel}>{label}</span>
              <span style={styles.confirmValue}>{value}</span>
            </div>
          ))}
        </div>

        <button style={styles.shopAgainBtn} onClick={() => navigate('/')}>
          Continue Shopping
        </button>
      </div>
    </div>
  );

  // ════════════════════════════════════════════
  // SCREEN 1 — Checkout Form
  // ════════════════════════════════════════════

  // Helper to render a labelled input field
  const Field = ({ label, name, placeholder, type = 'text' }) => (
    <div style={styles.fieldWrap}>
      <label style={styles.label}>{label}</label>
      <input
        type={type}
        name={name}
        placeholder={placeholder}
        value={form[name]}
        onChange={handleChange}
        style={{ ...styles.input, ...(errors[name] ? styles.inputError : {}) }}
        autoComplete="off"
      />
      {errors[name] && <p style={styles.errorMsg}>⚠ {errors[name]}</p>}
    </div>
  );

  return (
    <div style={styles.page}>
      <div style={styles.breadcrumb}>
        <Link to="/cart" style={styles.breadLink}>Cart</Link>
        <span style={styles.breadSep}> / </span>
        <span style={styles.breadCurrent}>Checkout</span>
      </div>

      <h1 style={styles.heading}>Checkout</h1>

      <div style={styles.layout}>

        {/* ── LEFT: Form ── */}
        <div>
          {/* Shipping Section */}
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>
              <span style={styles.sectionNum}>1</span> Shipping Information
            </h3>
            <Field label="Full Name"      name="fullName"   placeholder="Jane Doe" />
            <Field label="Email Address"  name="email"      placeholder="jane@example.com" type="email" />
            <Field label="Street Address" name="address"    placeholder="123 Main Street" />
            <div style={styles.row2}>
              <Field label="City"         name="city"       placeholder="Chennai" />
              <Field label="ZIP / Postal" name="zipCode"    placeholder="600001" />
            </div>
          </div>

          {/* Payment Section */}
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>
              <span style={styles.sectionNum}>2</span> Payment Details
            </h3>
            <p style={styles.secureNote}>🔒 Your card info is masked before storage. We never save full card numbers.</p>
            <Field label="Card Number" name="cardNumber" placeholder="1234 5678 9012 3456" />
          </div>

          {/* Place Order Button */}
          <button
            style={{ ...styles.placeBtn, ...(submitting ? styles.placeBtnDisabled : {}) }}
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting ? '⏳ Placing Order...' : `Place Order — $${total.toFixed(2)}`}
          </button>
        </div>

        {/* ── RIGHT: Order Summary ── */}
        <div style={styles.summary}>
          <h3 style={styles.summaryTitle}>Your Order</h3>

          {items.length === 0 ? (
            <p style={{ color: '#999', fontSize: '0.875rem' }}>
              Cart is empty. <Link to="/" style={{ color: '#1a1a2e' }}>Add items</Link> first.
            </p>
          ) : (
            <>
              {items.map(item => (
                <div key={item.id} style={styles.summaryItem}>
                  <div style={styles.summaryItemLeft}>
                    <span style={styles.summaryQtyBadge}>{item.quantity}</span>
                    <span style={styles.summaryItemName}>{item.name}</span>
                  </div>
                  <span style={styles.summaryItemPrice}>
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}

              <div style={styles.summaryDivider} />

              <div style={styles.summaryRow}>
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div style={styles.summaryRow}>
                <span>Shipping</span>
                <span>${shipping.toFixed(2)}</span>
              </div>
              <div style={styles.summaryTotal}>
                <span>Total</span>
                <span style={styles.summaryTotalAmt}>${total.toFixed(2)}</span>
              </div>
            </>
          )}
        </div>

      </div>
    </div>
  );
}

const styles = {
  page: { padding: '28px 32px', maxWidth: '1100px', margin: '0 auto' },
  breadcrumb: { display: 'flex', alignItems: 'center', marginBottom: '20px', fontSize: '0.85rem' },
  breadLink: { color: '#888', textDecoration: 'none' },
  breadSep: { color: '#ccc', margin: '0 8px' },
  breadCurrent: { color: '#333', fontWeight: 500 },
  heading: { fontSize: '1.6rem', fontWeight: 700, color: '#1a1a2e', marginBottom: '28px' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 340px', gap: '40px', alignItems: 'start' },

  // Form sections
  section: {
    background: '#fff', border: '1px solid #f0f0f0', borderRadius: '14px',
    padding: '24px', marginBottom: '20px',
    boxShadow: '0 1px 6px rgba(0,0,0,0.04)',
  },
  sectionTitle: {
    fontWeight: 700, fontSize: '1rem', color: '#1a1a2e',
    marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px',
  },
  sectionNum: {
    width: '26px', height: '26px', background: '#1a1a2e', color: '#fff',
    borderRadius: '50%', display: 'inline-flex', alignItems: 'center',
    justifyContent: 'center', fontSize: '0.8rem', fontWeight: 700, flexShrink: 0,
  },
  secureNote: { fontSize: '0.78rem', color: '#27ae60', marginBottom: '14px', fontWeight: 500 },
  fieldWrap: { marginBottom: '16px' },
  label: {
    display: 'block', fontSize: '0.78rem', fontWeight: 600, color: '#555',
    marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px',
  },
  input: {
    width: '100%', padding: '11px 13px', border: '1.5px solid #e8e8e8',
    borderRadius: '8px', fontSize: '0.95rem', color: '#222',
    outline: 'none', transition: 'border-color 0.15s', background: '#fafafa',
  },
  inputError: { borderColor: '#e94560', background: '#fff5f5' },
  errorMsg: { color: '#e94560', fontSize: '0.78rem', marginTop: '5px' },
  row2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  placeBtn: {
    width: '100%', padding: '15px', background: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '10px', cursor: 'pointer',
    fontWeight: 700, fontSize: '1rem',
  },
  placeBtnDisabled: { background: '#aaa', cursor: 'not-allowed' },

  // Order summary sidebar
  summary: {
    background: '#fff', border: '1px solid #f0f0f0', borderRadius: '14px',
    padding: '24px', boxShadow: '0 2px 12px rgba(0,0,0,0.05)',
    position: 'sticky', top: '80px',
  },
  summaryTitle: { fontWeight: 700, fontSize: '1rem', color: '#1a1a2e', marginBottom: '18px' },
  summaryItem: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
    marginBottom: '12px', gap: '8px',
  },
  summaryItemLeft: { display: 'flex', alignItems: 'flex-start', gap: '8px', flex: 1 },
  summaryQtyBadge: {
    background: '#1a1a2e', color: '#fff', borderRadius: '4px',
    padding: '1px 6px', fontSize: '0.75rem', fontWeight: 700, flexShrink: 0,
  },
  summaryItemName: { fontSize: '0.82rem', color: '#444', lineHeight: '1.4' },
  summaryItemPrice: { fontSize: '0.85rem', fontWeight: 600, flexShrink: 0 },
  summaryDivider: { borderTop: '1px solid #f0f0f0', margin: '16px 0' },
  summaryRow: {
    display: 'flex', justifyContent: 'space-between',
    fontSize: '0.875rem', color: '#666', marginBottom: '10px',
  },
  summaryTotal: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    borderTop: '2px solid #f0f0f0', paddingTop: '14px', marginTop: '6px',
    fontWeight: 700, fontSize: '1rem',
  },
  summaryTotalAmt: { fontSize: '1.25rem', color: '#1a1a2e' },

  // Confirmation screen
  confirmPage: {
    minHeight: '80vh', display: 'flex', alignItems: 'center',
    justifyContent: 'center', padding: '40px',
  },
  confirmCard: {
    background: '#fff', borderRadius: '20px', padding: '48px 40px',
    maxWidth: '480px', width: '100%', textAlign: 'center',
    boxShadow: '0 8px 40px rgba(0,0,0,0.1)',
  },
  checkCircle: {
    width: '72px', height: '72px', borderRadius: '50%', background: '#27ae60',
    color: '#fff', fontSize: '2rem', fontWeight: 700,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    margin: '0 auto 20px',
  },
  confirmTitle: { fontSize: '1.7rem', fontWeight: 700, color: '#1a1a2e', marginBottom: '10px' },
  confirmSub: { color: '#666', fontSize: '0.95rem', lineHeight: '1.6', marginBottom: '28px' },
  confirmDetails: {
    background: '#f9f9f9', borderRadius: '10px', padding: '20px',
    marginBottom: '28px', textAlign: 'left',
  },
  confirmRow: {
    display: 'flex', justifyContent: 'space-between', gap: '12px',
    padding: '10px 0', borderBottom: '1px solid #eee',
  },
  confirmLabel: { fontSize: '0.82rem', color: '#888', fontWeight: 600 },
  confirmValue: { fontSize: '0.85rem', color: '#222', fontWeight: 600, textAlign: 'right' },
  shopAgainBtn: {
    width: '100%', padding: '14px', background: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '10px', cursor: 'pointer',
    fontWeight: 700, fontSize: '1rem',
  },
};

export default Checkout;
