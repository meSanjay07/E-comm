import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../services/api';

/**
 * PDP — Product Detail Page  (Route: /product/:id)
 *
 * ── HOW A SINGLE PRODUCT'S DETAIL IS FETCHED ─────────────
 *
 *  1. User clicks "View Details" on product card (id = e.g. 3)
 *  2. React Router navigates to /product/3
 *  3. This component mounts, useParams() extracts { id: "3" }
 *  4. useEffect fires → api.getProduct(3) is called
 *  5. fetch("http://localhost:8080/api/products/3") is sent
 *  6. Spring Boot: GET /api/products/3
 *       → productService.getProductById(3)
 *       → productRepository.findById(3)
 *       → SELECT * FROM products WHERE id = 3
 *       → Returns ONE Product object as JSON
 *  7. React receives the JSON object → setProduct(data)
 *  8. Component re-renders with full product details ✅
 *
 * ── WHY useEffect has [id] in the dependency array ────────
 *  If user navigates from /product/1 to /product/2 without
 *  unmounting this component, we need the effect to re-run
 *  with the new id. The [id] dep array makes that happen.
 *  Without it, the page would not refresh with new data.
 *
 * ── ADD TO CART FLOW ──────────────────────────────────────
 *  User clicks "Add to Cart"
 *  → api.addToCart() sends POST /api/cart with product data
 *  → CartController checks if product already in cart:
 *      Yes → increments quantity in cart_items row
 *      No  → inserts new cart_items row
 *  → refreshCartCount() re-fetches cart total for Navbar badge
 */
function PDP({ refreshCartCount }) {
  const { id } = useParams();    // extracts the :id from the URL
  const navigate = useNavigate();

  const [product, setProduct]   = useState(null);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState(null);
  const [imgError, setImgError] = useState(false);
  const [added, setAdded]       = useState(false);
  const [adding, setAdding]     = useState(false);

  // ── Fetch single product by id from API ─────────────────
  useEffect(() => {
    setLoading(true);
    setAdded(false);
    setImgError(false);
    api.getProduct(id)
      .then(data => {
        setProduct(data);
        setLoading(false);
      })
      .catch(() => {
        setError('Product not found or server is unavailable.');
        setLoading(false);
      });
  }, [id]); // re-runs when :id changes in the URL

  // ── Add to Cart ─────────────────────────────────────────
  const handleAddToCart = () => {
    if (adding || added) return;
    setAdding(true);
    api.addToCart({
      productId: product.id,
      name:      product.name,
      price:     product.price,
      imageUrl:  product.imageUrl,
      quantity:  1,
    })
      .then(() => {
        refreshCartCount();  // updates Navbar badge count
        setAdded(true);
        setAdding(false);
        setTimeout(() => setAdded(false), 3000);
      })
      .catch(() => setAdding(false));
  };

  // ── Loading ──────────────────────────────────────────────
  if (loading) return (
    <div style={styles.center}>
      <div style={styles.spinner} />
      <p style={{ color: '#888', fontSize: '0.9rem' }}>Fetching product details...</p>
    </div>
  );

  // ── Error ────────────────────────────────────────────────
  if (error) return (
    <div style={styles.center}>
      <p style={{ color: '#dc2626', marginBottom: '12px' }}>⚠️ {error}</p>
      <button style={styles.backBtn} onClick={() => navigate('/')}>← Back to Products</button>
    </div>
  );

  return (
    <div style={styles.page}>

      {/* Breadcrumb — Home / Category / Product Name */}
      <div style={styles.breadcrumb}>
        <Link to="/" style={styles.breadLink}>Home</Link>
        <span style={styles.sep}> / </span>
        <span style={styles.breadLink} onClick={() => navigate('/')}>
          {product.category}
        </span>
        <span style={styles.sep}> / </span>
        <span style={styles.breadCurrent}>{product.name}</span>
      </div>

      <div style={styles.layout}>

        {/* LEFT — Product Image (imageUrl comes from products.json via API) */}
        <div style={styles.imgWrap}>
          {imgError ? (
            <div style={styles.imgFallback}>🖼</div>
          ) : (
            <img
              src={product.imageUrl}
              alt={product.name}
              style={styles.img}
              onError={() => setImgError(true)}
            />
          )}
        </div>

        {/* RIGHT — Product Details */}
        <div style={styles.details}>
          <span style={styles.catBadge}>{product.category}</span>
          <h1 style={styles.name}>{product.name}</h1>
          <p style={styles.price}>${product.price.toFixed(2)}</p>

          {/* Full description from products.json */}
          <p style={styles.desc}>{product.description}</p>

          {/* API Data Fields — shown explicitly so you see what came from JSON */}
          <div style={styles.metaGrid}>
            <div style={styles.metaItem}>
              <span style={styles.metaLabel}>Product ID</span>
              <span style={styles.metaValue}>#{product.id}</span>
            </div>
            <div style={styles.metaItem}>
              <span style={styles.metaLabel}>Category</span>
              <span style={styles.metaValue}>{product.category}</span>
            </div>
            <div style={styles.metaItem}>
              <span style={styles.metaLabel}>Price</span>
              <span style={styles.metaValue}>${product.price.toFixed(2)}</span>
            </div>
            <div style={styles.metaItem}>
              <span style={styles.metaLabel}>Stock</span>
              <span style={{
                ...styles.metaValue,
                color: product.stock > 10 ? '#1d9e75' : product.stock > 0 ? '#d97706' : '#dc2626'
              }}>
                {product.stock > 0 ? `${product.stock} units` : 'Out of Stock'}
              </span>
            </div>
          </div>

          {/* Add to Cart */}
          <button
            style={{
              ...styles.addBtn,
              ...(added   ? styles.addedBtn   : {}),
              ...(adding  ? styles.addingBtn  : {}),
              ...(product.stock === 0 ? styles.disabledBtn : {}),
            }}
            onClick={handleAddToCart}
            disabled={product.stock === 0 || adding}
          >
            {adding ? '⏳ Adding...' : added ? '✓  Added to Cart!' : '🛒  Add to Cart'}
          </button>

          {added && (
            <Link to="/cart" style={styles.viewCartLink}>View Cart →</Link>
          )}

          <button style={styles.backBtn} onClick={() => navigate(-1)}>
            ← Back to Products
          </button>
        </div>
      </div>

      {/* API Source Info Banner */}
      <div style={styles.apiInfo}>
        <span style={styles.apiInfoText}>
          📡 This page fetched product #{product.id} from{' '}
          <code style={styles.apiCode}>GET /api/products/{product.id}</code>
          {' '}— originally seeded from <code style={styles.apiCode}>products.json</code>
        </span>
      </div>

    </div>
  );
}

const styles = {
  page: { padding: '24px 32px', maxWidth: '1050px', margin: '0 auto' },
  center: { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: '12px' },
  spinner: { width: '36px', height: '36px', border: '3px solid #eee', borderTop: '3px solid #1a1a2e', borderRadius: '50%', animation: 'spin 0.8s linear infinite' },
  breadcrumb: { display: 'flex', alignItems: 'center', gap: '2px', marginBottom: '22px', fontSize: '0.82rem', flexWrap: 'wrap' },
  breadLink: { color: '#888', textDecoration: 'none', cursor: 'pointer' },
  sep: { color: '#ccc', margin: '0 4px' },
  breadCurrent: { color: '#333', fontWeight: 500, maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '48px', alignItems: 'start', marginBottom: '28px' },
  imgWrap: { borderRadius: '16px', overflow: 'hidden', boxShadow: '0 4px 24px rgba(0,0,0,0.08)' },
  img: { width: '100%', aspectRatio: '1/1', objectFit: 'cover', display: 'block' },
  imgFallback: { aspectRatio: '1/1', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f5f5f5', fontSize: '5rem' },
  details: { display: 'flex', flexDirection: 'column', gap: '14px' },
  catBadge: { display: 'inline-block', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', color: '#fff', background: '#1a1a2e', padding: '4px 10px', borderRadius: '4px', alignSelf: 'flex-start' },
  name: { fontSize: '1.65rem', fontWeight: 700, lineHeight: '1.25', color: '#1a1a2e', margin: 0 },
  price: { fontSize: '2rem', fontWeight: 800, color: '#e94560', margin: 0 },
  desc: { fontSize: '0.92rem', color: '#555', lineHeight: '1.75' },
  metaGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', background: '#f9f9f9', borderRadius: '10px', padding: '14px' },
  metaItem: { display: 'flex', flexDirection: 'column', gap: '2px' },
  metaLabel: { fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.5px', color: '#999', fontWeight: 600 },
  metaValue: { fontSize: '0.875rem', fontWeight: 600, color: '#333' },
  addBtn: { padding: '14px 24px', fontSize: '1rem', fontWeight: 700, border: 'none', borderRadius: '10px', background: '#1a1a2e', color: '#fff', cursor: 'pointer' },
  addedBtn: { background: '#1d9e75' },
  addingBtn: { background: '#555', cursor: 'not-allowed' },
  disabledBtn: { background: '#ccc', cursor: 'not-allowed' },
  viewCartLink: { display: 'block', textAlign: 'center', color: '#1a1a2e', fontWeight: 600, fontSize: '0.9rem', textDecoration: 'underline' },
  backBtn: { background: 'none', border: '1px solid #ddd', borderRadius: '8px', padding: '9px 18px', cursor: 'pointer', color: '#555', fontSize: '0.875rem', alignSelf: 'flex-start' },
  apiInfo: { background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px', padding: '10px 16px' },
  apiInfoText: { fontSize: '0.78rem', color: '#3b82f6' },
  apiCode: { background: '#dbeafe', padding: '1px 5px', borderRadius: '3px', fontFamily: 'monospace', fontSize: '0.75rem', color: '#1d4ed8' },
};

export default PDP;
