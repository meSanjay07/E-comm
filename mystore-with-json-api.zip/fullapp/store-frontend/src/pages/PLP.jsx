import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

/**
 * PLP — Product Listing Page  (Route: /)
 *
 * ── HOW PRODUCTS FROM products.json APPEAR HERE ──────────
 *
 *  1. Spring Boot starts → DataSeeder.run() fires
 *  2. DataSeeder reads products.json → saves 8 Product rows to H2
 *  3. React app opens in browser → this component mounts
 *  4. useEffect runs (once, because of the [] dependency array)
 *  5. api.getProducts() calls fetch("http://localhost:8080/api/products")
 *  6. Spring's ProductController handles the request:
 *       GET /api/products → productService.getAllProducts()
 *       → productRepository.findAll() → SELECT * FROM products
 *       → returns List<Product> → Jackson converts to JSON array
 *  7. fetch() receives the JSON → .then(res => res.json()) parses it
 *  8. setProducts(data) stores the JS array in React state
 *  9. React re-renders → .map() creates a ProductCard for each item
 *  10. Product grid appears on screen ✅
 *
 * ── FILTERING ────────────────────────────────────────────
 *  No second API call is made for filtering.
 *  We already have ALL products in state from step 8.
 *  The filtered array is computed in JS using .filter().
 *  React re-renders instantly when activeCat changes.
 *
 * ── STATE VARIABLES ──────────────────────────────────────
 *  products   — full array from API (never changes after load)
 *  activeCat  — currently selected filter tab
 *  loading    — true while API call is in progress
 *  error      — holds error message if API call fails
 */
function PLP({ refreshCartCount }) {
  const [products, setProducts] = useState([]);
  const [activeCat, setActiveCat] = useState('All');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // ── Fetch all products on first mount ──────────────────
  useEffect(() => {
    setLoading(true);
    api.getProducts()
      .then(data => {
        setProducts(data);   // store the JSON array from Spring Boot
        setLoading(false);
      })
      .catch(err => {
        setError('Could not connect to the backend. Make sure Spring Boot is running on port 8080.');
        setLoading(false);
      });
  }, []); // [] means: run only once when component first mounts

  // ── Derive category list from fetched data ──────────────
  // new Set() removes duplicates; spread [...] converts back to array
  const categories = ['All', ...new Set(products.map(p => p.category))];

  // ── Derive filtered list (no API call needed) ───────────
  const filtered = activeCat === 'All'
    ? products
    : products.filter(p => p.category === activeCat);

  // ── Loading state ───────────────────────────────────────
  if (loading) return (
    <div style={styles.center}>
      <div style={styles.spinner} />
      <p style={styles.loadingText}>Loading products from API...</p>
    </div>
  );

  // ── Error state ─────────────────────────────────────────
  if (error) return (
    <div style={styles.center}>
      <div style={styles.errorBox}>
        <p style={styles.errorTitle}>⚠️ Connection Error</p>
        <p style={styles.errorMsg}>{error}</p>
        <code style={styles.code}>cd store && mvn spring-boot:run</code>
        <button style={styles.retryBtn} onClick={() => window.location.reload()}>
          Retry
        </button>
      </div>
    </div>
  );

  return (
    <div style={styles.page}>
      <h1 style={styles.heading}>All Products</h1>
      <p style={styles.subheading}>
        Showing {filtered.length} of {products.length} products
        — data loaded from <code style={styles.inlineCode}>products.json</code> via Spring Boot API
      </p>

      {/* ── Category Filter Tabs ── */}
      <div style={styles.tabs}>
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCat(cat)}
            style={{
              ...styles.tab,
              ...(activeCat === cat ? styles.activeTab : {})
            }}
          >
            {cat}
            <span style={{
              ...styles.tabCount,
              ...(activeCat === cat ? styles.activeTabCount : {})
            }}>
              {cat === 'All' ? products.length : products.filter(p => p.category === cat).length}
            </span>
          </button>
        ))}
      </div>

      {/* ── Product Grid ── */}
      <div style={styles.grid}>
        {filtered.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            onViewDetails={() => navigate(`/product/${product.id}`)}
          />
        ))}
      </div>
    </div>
  );
}

/**
 * PRODUCT CARD — Sub-component
 *
 * Receives a single product object (from the API JSON) and renders it.
 * product.imageUrl is the Unsplash URL stored in products.json.
 *
 * onError fallback: if the image URL fails to load (e.g. no internet),
 * we show a grey placeholder box instead of a broken image icon.
 */
function ProductCard({ product, onViewDetails }) {
  const [imgError, setImgError] = useState(false);

  return (
    <div style={styles.card} onClick={onViewDetails}>
      {/* Product Image — src comes from product.imageUrl (Unsplash URL) */}
      {imgError ? (
        <div style={styles.imgFallback}>
          <span style={{ fontSize: '2rem', opacity: 0.3 }}>🖼</span>
        </div>
      ) : (
        <img
          src={product.imageUrl}
          alt={product.name}
          style={styles.img}
          onError={() => setImgError(true)}
        />
      )}

      <div style={styles.cardBody}>
        <span style={styles.catBadge}>{product.category}</span>
        <p style={styles.name}>{product.name}</p>

        {/* Stock indicator */}
        <div style={styles.stockRow}>
          <span style={{
            ...styles.stockDot,
            background: product.stock > 10 ? '#1d9e75' : product.stock > 0 ? '#f59e0b' : '#e94560'
          }} />
          <span style={styles.stockText}>
            {product.stock > 10 ? 'In Stock' : product.stock > 0 ? `Only ${product.stock} left` : 'Out of Stock'}
          </span>
        </div>

        <div style={styles.cardFooter}>
          <span style={styles.price}>${product.price.toFixed(2)}</span>
          <button
            style={styles.viewBtn}
            onClick={e => { e.stopPropagation(); onViewDetails(); }}
          >
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: { padding: '28px 32px', maxWidth: '1200px', margin: '0 auto' },
  heading: { fontSize: '1.7rem', fontWeight: 700, color: '#1a1a2e', marginBottom: '6px' },
  subheading: { fontSize: '0.82rem', color: '#888', marginBottom: '22px', lineHeight: '1.5' },
  inlineCode: { background: '#f0f0f0', padding: '1px 6px', borderRadius: '4px', fontSize: '0.8rem', fontFamily: 'monospace', color: '#555' },
  center: { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: '16px' },
  spinner: {
    width: '36px', height: '36px', border: '3px solid #eee',
    borderTop: '3px solid #1a1a2e', borderRadius: '50%',
    animation: 'spin 0.8s linear infinite',
  },
  loadingText: { color: '#888', fontSize: '0.9rem' },
  errorBox: {
    background: '#fff5f5', border: '1px solid #fecaca', borderRadius: '12px',
    padding: '28px 32px', maxWidth: '440px', textAlign: 'center',
    display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'center',
  },
  errorTitle: { fontWeight: 700, fontSize: '1rem', color: '#dc2626' },
  errorMsg: { color: '#555', fontSize: '0.875rem', lineHeight: '1.5' },
  code: { background: '#1a1a2e', color: '#7dd3fc', padding: '8px 14px', borderRadius: '6px', fontSize: '0.8rem', fontFamily: 'monospace' },
  retryBtn: { padding: '8px 20px', background: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 600, marginTop: '4px' },
  tabs: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '20px' },
  tab: {
    display: 'flex', alignItems: 'center', gap: '6px',
    padding: '7px 16px', border: '1.5px solid #ddd', borderRadius: '20px',
    background: '#fff', cursor: 'pointer', fontSize: '0.875rem', fontWeight: 500, color: '#555',
  },
  activeTab: { background: '#1a1a2e', color: '#fff', borderColor: '#1a1a2e' },
  tabCount: { background: '#eee', color: '#666', borderRadius: '10px', padding: '0 6px', fontSize: '0.75rem', fontWeight: 700 },
  activeTabCount: { background: 'rgba(255,255,255,0.25)', color: '#fff' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(235px, 1fr))', gap: '22px' },
  card: {
    background: '#fff', border: '1px solid #eee', borderRadius: '14px',
    overflow: 'hidden', cursor: 'pointer',
    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
    transition: 'transform 0.15s, box-shadow 0.15s',
  },
  img: { width: '100%', height: '200px', objectFit: 'cover', display: 'block' },
  imgFallback: {
    width: '100%', height: '200px', background: '#f5f5f5',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  cardBody: { padding: '14px 16px' },
  catBadge: {
    fontSize: '10px', fontWeight: 700, textTransform: 'uppercase',
    letterSpacing: '0.8px', color: '#888', display: 'block', marginBottom: '6px',
  },
  name: {
    fontWeight: 600, fontSize: '0.9rem', color: '#1a1a2e',
    marginBottom: '8px', lineHeight: '1.35',
    display: '-webkit-box', WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical', overflow: 'hidden',
  },
  stockRow: { display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '10px' },
  stockDot: { width: '7px', height: '7px', borderRadius: '50%', flexShrink: 0 },
  stockText: { fontSize: '0.75rem', color: '#666' },
  cardFooter: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  price: { color: '#e94560', fontWeight: 700, fontSize: '1.05rem' },
  viewBtn: {
    padding: '7px 14px', background: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '8px', cursor: 'pointer',
    fontSize: '0.8rem', fontWeight: 600,
  },
};

export default PLP;
