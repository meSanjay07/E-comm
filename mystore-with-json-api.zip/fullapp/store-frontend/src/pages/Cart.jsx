import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../services/api';

/**
 * CART PAGE
 * Route: /cart
 *
 * WHAT IT DOES:
 *   Shows all CartItem rows from the backend with:
 *   - Product image, name, unit price
 *   - Quantity controls (+ and −)
 *   - Remove button per item
 *   - Order Summary sidebar (subtotal, shipping, total)
 *   - "Proceed to Checkout" button
 *   - Empty state when cart has no items
 *
 * KEY INTERACTIONS:
 *
 * updateQty(item, delta):
 *   delta = +1 (clicked +) or -1 (clicked −)
 *   If new qty < 1, we DELETE the item instead of setting qty=0
 *   Otherwise PUT the new quantity to backend, reload cart
 *
 * removeItem(id):
 *   DELETE /api/cart/:id
 *   Reloads cart and refreshes navbar badge
 *
 * clearCart():
 *   DELETE /api/cart (entire table wiped)
 *   Sets local items=[] immediately for instant UI feedback
 *
 * PRICING LOGIC:
 *   subtotal = sum of (price × quantity) for all items
 *   shipping  = $9.99 flat rate (free if cart empty)
 *   total     = subtotal + shipping
 */
function Cart({ refreshCartCount }) {
  const [items, setItems]     = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate              = useNavigate();

  const loadCart = () => {
    api.getCart()
      .then(data => { setItems(data); setLoading(false); })
      .catch(() => setLoading(false));
  };

  useEffect(() => { loadCart(); }, []);

  const updateQty = (item, delta) => {
    const newQty = item.quantity + delta;
    if (newQty < 1) {
      // quantity would go to 0 → remove item instead
      api.removeCartItem(item.id).then(() => { loadCart(); refreshCartCount(); });
    } else {
      api.updateCartItem(item.id, { ...item, quantity: newQty })
        .then(() => { loadCart(); refreshCartCount(); });
    }
  };

  const removeItem = (id) => {
    api.removeCartItem(id).then(() => { loadCart(); refreshCartCount(); });
  };

  const clearCart = () => {
    api.clearCart().then(() => { setItems([]); refreshCartCount(); });
  };

  // ── Pricing Calculations ──
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const shipping  = subtotal > 0 ? 9.99 : 0;
  const total     = subtotal + shipping;

  if (loading) return <div style={styles.center}>⏳ Loading cart...</div>;

  // ── Empty Cart State ──
  if (items.length === 0) return (
    <div style={styles.emptyPage}>
      <div style={styles.emptyIcon}>🛒</div>
      <h2 style={styles.emptyTitle}>Your cart is empty</h2>
      <p style={styles.emptySub}>Looks like you haven't added anything yet.</p>
      <button style={styles.shopBtn} onClick={() => navigate('/')}>
        Browse Products
      </button>
    </div>
  );

  return (
    <div style={styles.page}>
      <div style={styles.headerRow}>
        <h1 style={styles.heading}>Shopping Cart</h1>
        <button style={styles.clearBtn} onClick={clearCart}>Clear All</button>
      </div>

      <div style={styles.layout}>

        {/* ── LEFT: Cart Item List ── */}
        <div>
          {items.map(item => (
            <CartRow
              key={item.id}
              item={item}
              onIncrease={() => updateQty(item, +1)}
              onDecrease={() => updateQty(item, -1)}
              onRemove={() => removeItem(item.id)}
            />
          ))}
        </div>

        {/* ── RIGHT: Order Summary ── */}
        <div style={styles.summary}>
          <h3 style={styles.summaryTitle}>Order Summary</h3>

          <div style={styles.summaryRows}>
            <div style={styles.summaryRow}>
              <span>Subtotal ({items.reduce((s,i) => s + i.quantity, 0)} items)</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div style={styles.summaryRow}>
              <span>Shipping</span>
              <span>${shipping.toFixed(2)}</span>
            </div>
          </div>

          <div style={styles.totalRow}>
            <span>Total</span>
            <span style={styles.totalAmt}>${total.toFixed(2)}</span>
          </div>

          <button style={styles.checkoutBtn} onClick={() => navigate('/checkout')}>
            Proceed to Checkout →
          </button>

          <Link to="/" style={styles.continueLink}>
            ← Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
}

/**
 * CART ROW — Sub-component for each line item
 *
 * Extracted to keep Cart component readable.
 * Receives item data and event handlers as props.
 */
function CartRow({ item, onIncrease, onDecrease, onRemove }) {
  const [imgError, setImgError] = useState(false);
  return (
    <div style={styles.row}>
      {imgError ? (
        <div style={styles.rowImgPlaceholder}>🖼</div>
      ) : (
        <img
          src={`http://localhost:8080${item.imageUrl}`}
          alt={item.name}
          style={styles.rowImg}
          onError={() => setImgError(true)}
        />
      )}
      <div style={styles.rowInfo}>
        <p style={styles.rowName}>{item.name}</p>
        <p style={styles.rowUnitPrice}>${item.price.toFixed(2)} each</p>
      </div>
      <div style={styles.qtyControl}>
        <button style={styles.qtyBtn} onClick={onDecrease}>−</button>
        <span style={styles.qtyValue}>{item.quantity}</span>
        <button style={styles.qtyBtn} onClick={onIncrease}>+</button>
      </div>
      <p style={styles.rowTotal}>${(item.price * item.quantity).toFixed(2)}</p>
      <button style={styles.removeBtn} onClick={onRemove} title="Remove">✕</button>
    </div>
  );
}

const styles = {
  page: { padding: '28px 32px', maxWidth: '1100px', margin: '0 auto' },
  center: { textAlign: 'center', padding: '80px', color: '#888', fontSize: '1.1rem' },
  headerRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' },
  heading: { fontSize: '1.6rem', fontWeight: 700, color: '#1a1a2e' },
  clearBtn: {
    background: 'none', border: '1px solid #e0e0e0', borderRadius: '6px',
    padding: '7px 14px', cursor: 'pointer', color: '#999', fontSize: '0.8rem',
  },
  layout: { display: 'grid', gridTemplateColumns: '1fr 320px', gap: '32px', alignItems: 'start' },
  row: {
    display: 'flex', alignItems: 'center', gap: '16px',
    padding: '18px 0', borderBottom: '1px solid #f0f0f0', background: '#fff',
    borderRadius: '10px', marginBottom: '8px', padding: '16px',
    boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
  },
  rowImg: { width: '76px', height: '76px', objectFit: 'cover', borderRadius: '10px', flexShrink: 0 },
  rowImgPlaceholder: {
    width: '76px', height: '76px', borderRadius: '10px',
    background: '#f5f5f5', display: 'flex', alignItems: 'center',
    justifyContent: 'center', fontSize: '1.8rem', flexShrink: 0,
  },
  rowInfo: { flex: 1 },
  rowName: { fontWeight: 600, fontSize: '0.9rem', color: '#1a1a2e', marginBottom: '4px' },
  rowUnitPrice: { fontSize: '0.8rem', color: '#999' },
  qtyControl: { display: 'flex', alignItems: 'center', gap: '10px' },
  qtyBtn: {
    width: '30px', height: '30px', border: '1px solid #e0e0e0', borderRadius: '6px',
    background: '#fff', cursor: 'pointer', fontSize: '1rem', fontWeight: 700,
    color: '#333', display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  qtyValue: { minWidth: '24px', textAlign: 'center', fontWeight: 700, fontSize: '0.95rem' },
  rowTotal: { fontWeight: 700, fontSize: '0.95rem', minWidth: '64px', textAlign: 'right' },
  removeBtn: {
    background: 'none', border: 'none', cursor: 'pointer',
    color: '#ccc', fontSize: '1rem', padding: '4px',
  },
  summary: {
    background: '#fff', border: '1px solid #f0f0f0', borderRadius: '14px',
    padding: '24px', boxShadow: '0 2px 12px rgba(0,0,0,0.05)',
    display: 'flex', flexDirection: 'column', gap: '0',
  },
  summaryTitle: { fontWeight: 700, fontSize: '1rem', color: '#1a1a2e', marginBottom: '20px' },
  summaryRows: { display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '20px' },
  summaryRow: {
    display: 'flex', justifyContent: 'space-between',
    fontSize: '0.875rem', color: '#666',
  },
  totalRow: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    borderTop: '2px solid #f0f0f0', paddingTop: '16px', marginBottom: '20px',
    fontWeight: 700, fontSize: '1rem',
  },
  totalAmt: { fontSize: '1.3rem', color: '#1a1a2e' },
  checkoutBtn: {
    width: '100%', padding: '14px', background: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '10px', cursor: 'pointer',
    fontWeight: 700, fontSize: '0.95rem', marginBottom: '12px',
  },
  continueLink: {
    display: 'block', textAlign: 'center', color: '#888',
    fontSize: '0.85rem', textDecoration: 'none',
  },
  emptyPage: {
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', minHeight: '60vh', gap: '12px',
  },
  emptyIcon: { fontSize: '4rem', marginBottom: '8px' },
  emptyTitle: { fontSize: '1.4rem', fontWeight: 700, color: '#1a1a2e' },
  emptySub: { color: '#888', fontSize: '0.95rem' },
  shopBtn: {
    marginTop: '12px', padding: '12px 28px', background: '#1a1a2e',
    color: '#fff', border: 'none', borderRadius: '10px',
    cursor: 'pointer', fontWeight: 600, fontSize: '0.95rem',
  },
};

export default Cart;
