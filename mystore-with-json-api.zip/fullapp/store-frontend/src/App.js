import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import PLP from './pages/PLP';
import PDP from './pages/PDP';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import api from './services/api';

/**
 * APP.JS — Root Component
 *
 * This is the TOP of the React component tree.
 * Every other component lives inside this one.
 *
 * WHAT IT DOES:
 * 1. Sets up React Router — handles URL navigation without full page reloads
 * 2. Holds cartCount in state — shared across Navbar, Cart, and PDP
 * 3. Provides refreshCartCount() — any child can call this to update the badge
 *
 * COMPONENT TREE:
 *   App
 *   ├── Navbar        (always visible — shows cart badge)
 *   └── Routes
 *       ├── /           → PLP  (product listing grid)
 *       ├── /product/:id → PDP  (product detail page)
 *       ├── /cart        → Cart (cart page with qty controls)
 *       └── /checkout    → Checkout (form + confirmation)
 *
 * STATE: cartCount
 *   Stored here (not in Navbar) so both Navbar AND other pages
 *   can read/update it. This is called "lifting state up".
 *
 * useCallback: prevents refreshCartCount from being recreated on
 * every render, which would cause infinite loops in useEffect deps.
 */
function App() {
  const [cartCount, setCartCount] = useState(0);

  // Fetch total item count from backend and update navbar badge
  const refreshCartCount = useCallback(() => {
    api.getCart()
      .then(items => {
        const total = items.reduce((sum, item) => sum + item.quantity, 0);
        setCartCount(total);
      })
      .catch(() => setCartCount(0));
  }, []);

  // Load cart count once when app first opens
  useEffect(() => {
    refreshCartCount();
  }, [refreshCartCount]);

  return (
    <BrowserRouter>
      {/* Navbar is outside Routes so it shows on every page */}
      <Navbar cartCount={cartCount} />

      <Routes>
        {/* Pass refreshCartCount so pages can update the badge */}
        <Route path="/"            element={<PLP refreshCartCount={refreshCartCount} />} />
        <Route path="/product/:id" element={<PDP refreshCartCount={refreshCartCount} />} />
        <Route path="/cart"        element={<Cart refreshCartCount={refreshCartCount} />} />
        <Route path="/checkout"    element={<Checkout refreshCartCount={refreshCartCount} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
