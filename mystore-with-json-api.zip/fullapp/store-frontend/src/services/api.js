/**
 * API SERVICE — api.js
 *
 * ─────────────────────────────────────────────────────────
 * THE COMPLETE PICTURE: How JSON becomes a rendered page
 * ─────────────────────────────────────────────────────────
 *
 *  products.json (file on disk)
 *       ↓  read by DataSeeder on startup
 *  H2 Database (in-memory table: "products")
 *       ↓  queried by ProductRepository.findAll()
 *  ProductService.getAllProducts()
 *       ↓  called by ProductController
 *  GET /api/products  (HTTP endpoint on port 8080)
 *       ↓  called by api.getProducts() below
 *  fetch() in the browser
 *       ↓  returns a Promise<Response>
 *  .then(res => res.json())
 *       ↓  parses the HTTP body as JSON → JS array of objects
 *  setProducts(data) in PLP.jsx
 *       ↓  React state update triggers re-render
 *  Product cards appear in the grid  ✅
 *
 * ─────────────────────────────────────────────────────────
 * WHY centralise API calls here?
 *   Single place to change the base URL (e.g. for production)
 *   Single place to add auth headers, error interceptors, etc.
 *   Components stay clean — they just call api.getProducts()
 * ─────────────────────────────────────────────────────────
 */

const BASE_URL = 'http://localhost:8080/api';

const api = {

  // ── PRODUCTS ─────────────────────────────────────────

  /**
   * GET /api/products
   * Fetches ALL products from H2 (originally loaded from products.json).
   * Used by PLP.jsx to populate the product grid.
   * Returns: Promise<Product[]>
   *
   * Product shape:
   * {
   *   id: number,
   *   name: string,
   *   description: string,
   *   price: number,
   *   stock: number,
   *   imageUrl: string,   ← Unsplash URL from products.json
   *   category: string
   * }
   */
  getProducts: () =>
    fetch(`${BASE_URL}/products`)
      .then(res => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json();
      }),

  /**
   * GET /api/products/:id
   * Fetches ONE product by its database ID.
   * Used by PDP.jsx to show full product details.
   * Returns: Promise<Product>
   *
   * Example: api.getProduct(3) calls GET /api/products/3
   * Spring Boot returns a single JSON object (not an array).
   */
  getProduct: (id) =>
    fetch(`${BASE_URL}/products/${id}`)
      .then(res => {
        if (!res.ok) throw new Error(`Product ${id} not found`);
        return res.json();
      }),

  // ── CART ─────────────────────────────────────────────

  getCart: () =>
    fetch(`${BASE_URL}/cart`)
      .then(res => res.json()),

  addToCart: (item) =>
    fetch(`${BASE_URL}/cart`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item),
    }).then(res => res.json()),

  updateCartItem: (id, item) =>
    fetch(`${BASE_URL}/cart/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(item),
    }).then(res => res.json()),

  removeCartItem: (id) =>
    fetch(`${BASE_URL}/cart/${id}`, { method: 'DELETE' }),

  clearCart: () =>
    fetch(`${BASE_URL}/cart`, { method: 'DELETE' }),

  // ── ORDERS ───────────────────────────────────────────

  placeOrder: (orderData) =>
    fetch(`${BASE_URL}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    }).then(res => res.json()),
};

export default api;
