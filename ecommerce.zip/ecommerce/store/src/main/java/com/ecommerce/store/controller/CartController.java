package com.ecommerce.store.controller;

import com.ecommerce.store.model.CartItem;
import com.ecommerce.store.repository.CartItemRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartItemRepository repo;

    public CartController(CartItemRepository repo) {
        this.repo = repo;
    }

    // GET /api/cart — fetch all cart items
    @GetMapping
    public List<CartItem> getCart() {
        return repo.findAll();
    }

    // POST /api/cart — add item (or increment qty if already exists)
    @PostMapping
    public CartItem addToCart(@RequestBody CartItem item) {
        List<CartItem> existing = repo.findAll();
        for (CartItem c : existing) {
            if (c.getProductId().equals(item.getProductId())) {
                c.setQuantity(c.getQuantity() + 1);
                return repo.save(c);
            }
        }
        item.setQuantity(1);
        return repo.save(item);
    }

    // PUT /api/cart/{id} — update quantity
    @PutMapping("/{id}")
    public ResponseEntity<CartItem> updateQty(@PathVariable Long id, @RequestBody CartItem updated) {
        return repo.findById(id).map(item -> {
            item.setQuantity(updated.getQuantity());
            return ResponseEntity.ok(repo.save(item));
        }).orElse(ResponseEntity.notFound().build());
    }

    // DELETE /api/cart/{id} — remove item
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeItem(@PathVariable Long id) {
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // DELETE /api/cart — clear entire cart
    @DeleteMapping
    public ResponseEntity<Void> clearCart() {
        repo.deleteAll();
        return ResponseEntity.noContent().build();
    }
}