package com.ecommerce.store.model;

import jakarta.persistence.*;

@Entity
@Table(name = "cart_items")
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long productId;
    private String name;
    private double price;
    private String imageUrl;
    private int quantity;

    public CartItem() {}

    public CartItem(Long productId, String name, double price, String imageUrl, int quantity) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
        this.quantity = quantity;
    }

    public Long getId()                        { return id; }
    public Long getProductId()                 { return productId; }
    public void setProductId(Long productId)   { this.productId = productId; }
    public String getName()                    { return name; }
    public void setName(String name)           { this.name = name; }
    public double getPrice()                   { return price; }
    public void setPrice(double price)         { this.price = price; }
    public String getImageUrl()                { return imageUrl; }
    public void setImageUrl(String url)        { this.imageUrl = url; }
    public int getQuantity()                   { return quantity; }
    public void setQuantity(int quantity)      { this.quantity = quantity; }
}