package com.ecommerce.store.model;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private double price;
    private int stock;
    private String imageUrl;
    private String category;

    public Product() {}

    public Product(String name, String description, double price,
                   int stock, String imageUrl, String category) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.stock = stock;
        this.imageUrl = imageUrl;
        this.category = category;
    }

    public Long getId()                      { return id; }
    public String getName()                  { return name; }
    public void setName(String name)         { this.name = name; }
    public String getDescription()           { return description; }
    public void setDescription(String d)     { this.description = d; }
    public double getPrice()                 { return price; }
    public void setPrice(double price)       { this.price = price; }
    public int getStock()                    { return stock; }
    public void setStock(int stock)          { this.stock = stock; }
    public String getImageUrl()              { return imageUrl; }
    public void setImageUrl(String url)      { this.imageUrl = url; }
    public String getCategory()              { return category; }
    public void setCategory(String cat)      { this.category = cat; }
}
