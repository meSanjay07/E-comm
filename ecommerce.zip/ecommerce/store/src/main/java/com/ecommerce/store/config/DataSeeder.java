package com.ecommerce.store.config;

import com.ecommerce.store.model.Product;
import com.ecommerce.store.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final ProductRepository repo;

    public DataSeeder(ProductRepository repo) {
        this.repo = repo;
    }

    @Override
    public void run(String... args) {
        repo.save(new Product(
            "Wireless Noise-Cancelling Headphones",
            "Premium over-ear headphones with 30-hour battery, active noise cancellation, and foldable design. Perfect for travel and work-from-home setups.",
            149.99, 23,
            "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600",
            "Electronics"
        ));
        repo.save(new Product(
            "Classic White Sneakers",
            "Minimalist leather sneakers with cushioned insole and durable rubber sole. Pairs effortlessly with any outfit.",
            89.99, 40,
            "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600",
            "Apparel"
        ));
        repo.save(new Product(
            "Stainless Steel Water Bottle",
            "Double-wall vacuum insulated bottle that keeps drinks cold 24 hours or hot 12 hours. BPA-free, leak-proof lid.",
            34.99, 65,
            "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600",
            "Accessories"
        ));
        repo.save(new Product(
            "Mechanical Keyboard",
            "Compact TKL layout with Cherry MX Brown switches, per-key RGB lighting, and aircraft-grade aluminium frame.",
            129.00, 15,
            "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600",
            "Electronics"
        ));
        repo.save(new Product(
            "Linen Oversized Shirt",
            "Breathable 100% linen shirt in a relaxed fit. Available in natural beige, sage green, and ocean blue.",
            59.99, 30,
            "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600",
            "Apparel"
        ));
    }
}
