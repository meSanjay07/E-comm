package com.ecommerce.store.controller;

import com.ecommerce.store.model.Order;
import com.ecommerce.store.repository.CartItemRepository;
import com.ecommerce.store.repository.OrderRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderRepository orderRepo;
    private final CartItemRepository cartRepo;

    public OrderController(OrderRepository orderRepo, CartItemRepository cartRepo) {
        this.orderRepo = orderRepo;
        this.cartRepo = cartRepo;
    }

    // POST /api/orders — place order and clear cart
    @PostMapping
    public ResponseEntity<Order> placeOrder(@RequestBody Order order) {
        // Mask card number — store last 4 digits only
        String card = order.getCardNumber();
        if (card != null && card.length() >= 4) {
            order.setCardNumber("****-****-****-" + card.substring(card.length() - 4));
        }
        Order saved = orderRepo.save(order);
        cartRepo.deleteAll();   // clear cart after successful order
        return ResponseEntity.ok(saved);
    }
}