import { Link } from 'react-router-dom';

function Navbar({ cartCount }) {
  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.brand}>🛍 MyStore</Link>
      <Link to="/cart" style={styles.cartLink}>
        🛒 Cart
        {cartCount > 0 && <span style={styles.badge}>{cartCount}</span>}
      </Link>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '14px 32px', background: '#1a1a2e',
    position: 'sticky', top: 0, zIndex: 100,
  },
  brand: { color: '#fff', textDecoration: 'none', fontSize: '1.3rem', fontWeight: 600 },
  cartLink: {
    color: '#fff', textDecoration: 'none', fontSize: '1rem',
    display: 'flex', alignItems: 'center', gap: '6px', position: 'relative',
  },
  badge: {
    background: '#e94560', color: '#fff', borderRadius: '50%',
    width: '20px', height: '20px', display: 'flex',
    alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700,
  },
};

export default Navbar;