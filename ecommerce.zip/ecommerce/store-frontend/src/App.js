import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import PLP from './pages/PLP';
import PDP from './pages/PDP';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';

const API = 'http://localhost:8080/api';

function App() {
  const [cartCount, setCartCount] = useState(0);

  const refreshCartCount = () => {
    fetch(`${API}/cart`)
      .then(res => res.json())
      .then(items => setCartCount(items.reduce((sum, i) => sum + i.quantity, 0)))
      .catch(() => {});
  };

  useEffect(() => { refreshCartCount(); }, []);

  return (
    <BrowserRouter>
      <Navbar cartCount={cartCount} />
      <Routes>
        <Route path="/" element={<PLP refreshCartCount={refreshCartCount} />} />
        <Route path="/product/:id" element={<PDP refreshCartCount={refreshCartCount} />} />
        <Route path="/cart" element={<Cart refreshCartCount={refreshCartCount} />} />
        <Route path="/checkout" element={<Checkout refreshCartCount={refreshCartCount} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;