import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const API = 'http://localhost:8080/api';

function PDP({ refreshCartCount }) {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [added, setAdded] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`${API}/products/${id}`)
      .then(res => res.json())
      .then(setProduct);
  }, [id]);

  const handleAdd = () => {
    fetch(`${API}/cart`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        productId: product.id,
        name: product.name,
        price: product.price,
        imageUrl: product.imageUrl,
        quantity: 1,
      }),
    })
      .then(() => {
        refreshCartCount();
        setAdded(true);
        setTimeout(() => setAdded(false), 2000);
      });
  };

  if (!product) return <p style={{ padding: '40px', textAlign: 'center' }}>Loading...</p>;

  return (
    <div style={styles.page}>
      <button onClick={() => navigate(-1)} style={styles.back}>← Back</button>
      <div style={styles.layout}>
        <img src={product.imageUrl} alt={product.name} style={styles.img} />
        <div style={styles.details}>
          <p style={styles.category}>{product.category}</p>
          <h1 style={styles.name}>{product.name}</h1>
          <p style={styles.price}>${product.price.toFixed(2)}</p>
          <p style={styles.desc}>{product.description}</p>
          <p style={styles.stock}>
            {product.stock > 0 ? `✅ In stock — ${product.stock} units available` : '❌ Out of stock'}
          </p>
          <button style={{ ...styles.btn, ...(added ? styles.addedBtn : {}) }}
            onClick={handleAdd} disabled={product.stock === 0}>
            {added ? '✓ Added to Cart!' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: { padding: '24px 32px', maxWidth: '1000px', margin: '0 auto' },
  back: { background: 'none', border: '1px solid #ddd', borderRadius: '8px', padding: '8px 16px', cursor: 'pointer', marginBottom: '24px' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', alignItems: 'start' },
  img: { width: '100%', borderRadius: '12px', objectFit: 'cover', aspectRatio: '1/1' },
  details: { display: 'flex', flexDirection: 'column', gap: '14px' },
  category: { color: '#888', fontWeight: 600, fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: '1px' },
  name: { fontSize: '1.6rem', fontWeight: 700, lineHeight: '1.3', margin: 0 },
  price: { fontSize: '1.8rem', fontWeight: 800, color: '#e94560', margin: 0 },
  desc: { color: '#444', lineHeight: '1.7', fontSize: '0.95rem' },
  stock: { fontWeight: 600, fontSize: '0.9rem' },
  btn: {
    padding: '14px', fontSize: '1rem', fontWeight: 700, border: 'none',
    borderRadius: '10px', background: '#1a1a2e', color: '#fff', cursor: 'pointer',
  },
  addedBtn: { background: '#27ae60' },
};

export default PDP;