import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const API = 'http://localhost:8080/api';

function Checkout({ refreshCartCount }) {
  const [items, setItems] = useState([]);
  const [confirmed, setConfirmed] = useState(null);
  const [form, setForm] = useState({
    fullName: '', email: '', address: '',
    city: '', zipCode: '', cardNumber: '',
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`${API}/cart`).then(r => r.json()).then(setItems);
  }, []);

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const shipping = subtotal > 0 ? 9.99 : 0;
  const total = subtotal + shipping;

  const validate = () => {
    const e = {};
    if (!form.fullName.trim())    e.fullName   = 'Name is required';
    if (!form.email.includes('@')) e.email     = 'Valid email required';
    if (!form.address.trim())     e.address    = 'Address is required';
    if (!form.city.trim())        e.city       = 'City is required';
    if (!form.zipCode.trim())     e.zipCode    = 'ZIP code is required';
    if (form.cardNumber.replace(/\s/g, '').length < 16)
                                  e.cardNumber = 'Enter a valid 16-digit card number';
    return e;
  };

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors(prev => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSubmit = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    fetch(`${API}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, totalAmount: total }),
    })
      .then(r => r.json())
      .then(order => {
        setConfirmed(order);
        refreshCartCount();
      });
  };

  // ── Order Confirmation Screen ──
  if (confirmed) return (
    <div style={styles.confirmPage}>
      <div style={styles.confirmBox}>
        <div style={styles.checkCircle}>✓</div>
        <h2 style={styles.confirmTitle}>Order Confirmed!</h2>
        <p style={styles.confirmSub}>Thank you, {confirmed.fullName}. Your order #{confirmed.id} has been placed.</p>
        <div style={styles.confirmDetail}>
          <div style={styles.confirmRow}><span>Order ID</span><strong>#{confirmed.id}</strong></div>
          <div style={styles.confirmRow}><span>Email</span><strong>{confirmed.email}</strong></div>
          <div style={styles.confirmRow}><span>Total Paid</span><strong>${confirmed.totalAmount.toFixed(2)}</strong></div>
          <div style={styles.confirmRow}><span>Card</span><strong>{confirmed.cardNumber}</strong></div>
        </div>
        <button style={styles.btn} onClick={() => navigate('/')}>Continue Shopping</button>
      </div>
    </div>
  );

  // ── Checkout Form ──
  const field = (label, name, placeholder, type = 'text') => (
    <div style={styles.fieldWrap}>
      <label style={styles.label}>{label}</label>
      <input
        type={type} name={name} placeholder={placeholder}
        value={form[name]} onChange={handleChange}
        style={{ ...styles.input, ...(errors[name] ? styles.inputErr : {}) }}
      />
      {errors[name] && <p style={styles.errMsg}>{errors[name]}</p>}
    </div>
  );

  return (
    <div style={styles.page}>
      <h2 style={styles.heading}>Checkout</h2>
      <div style={styles.layout}>

        {/* Left — Form */}
        <div>
          <h3 style={styles.sectionTitle}>Shipping Information</h3>
          {field('Full Name', 'fullName', 'Jane Doe')}
          {field('Email', 'email', 'jane@example.com', 'email')}
          {field('Address', 'address', '123 Main Street')}
          <div style={styles.row2}>
            {field('City', 'city', 'Chennai')}
            {field('ZIP Code', 'zipCode', '600001')}
          </div>

          <h3 style={{ ...styles.sectionTitle, marginTop: '28px' }}>Payment Details</h3>
          {field('Card Number', 'cardNumber', '1234 5678 9012 3456')}

          <button style={styles.btn} onClick={handleSubmit}>
            Place Order — ${total.toFixed(2)}
          </button>
        </div>

        {/* Right — Summary */}
        <div style={styles.summary}>
          <h3 style={styles.summaryTitle}>Order Summary</h3>
          {items.map(item => (
            <div key={item.id} style={styles.summaryItem}>
              <img src={item.imageUrl} alt={item.name} style={styles.summaryImg} />
              <div style={{ flex: 1 }}>
                <p style={styles.summaryName}>{item.name}</p>
                <p style={styles.summaryQty}>Qty: {item.quantity}</p>
              </div>
              <span style={styles.summaryPrice}>${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div style={styles.divider} />
          <div style={styles.summaryRow}><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
          <div style={styles.summaryRow}><span>Shipping</span><span>${shipping.toFixed(2)}</span></div>
          <div style={{ ...styles.summaryRow, ...styles.totalRow }}>
            <span>Total</span><span>${total.toFixed(2)}</span>
          </div>
        </div>

      </div>
    </div>
  );
}

const styles = {
  page: { padding: '24px 32px', maxWidth: '1100px', margin: '0 auto' },
  heading: { fontSize: '1.5rem', fontWeight: 700, marginBottom: '24px' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 360px', gap: '40px', alignItems: 'start' },
  sectionTitle: { fontWeight: 700, fontSize: '1rem', marginBottom: '16px', color: '#333' },
  fieldWrap: { marginBottom: '16px' },
  label: { display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#555', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.5px' },
  input: { width: '100%', padding: '10px 12px', border: '1px solid #ddd', borderRadius: '8px', fontSize: '0.95rem', outline: 'none' },
  inputErr: { borderColor: '#e94560' },
  errMsg: { color: '#e94560', fontSize: '0.78rem', marginTop: '4px' },
  row2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  btn: {
    marginTop: '8px', width: '100%', padding: '14px', background: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '1rem',
  },
  summary: { background: '#f9f9f9', border: '1px solid #eee', borderRadius: '12px', padding: '24px' },
  summaryTitle: { fontWeight: 700, fontSize: '1rem', marginBottom: '16px' },
  summaryItem: { display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '14px' },
  summaryImg: { width: '52px', height: '52px', objectFit: 'cover', borderRadius: '6px' },
  summaryName: { fontSize: '0.85rem', fontWeight: 600, marginBottom: '2px' },
  summaryQty: { fontSize: '0.78rem', color: '#888' },
  summaryPrice: { fontWeight: 700, fontSize: '0.9rem' },
  divider: { borderTop: '1px solid #eee', margin: '16px 0' },
  summaryRow: { display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: '#555', marginBottom: '8px' },
  totalRow: { fontWeight: 700, fontSize: '1rem', color: '#000', borderTop: '1px solid #ddd', paddingTop: '12px', marginTop: '4px' },
  confirmPage: { minHeight: '70vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px' },
  confirmBox: { textAlign: 'center', maxWidth: '460px', width: '100%' },
  checkCircle: {
    width: '72px', height: '72px', borderRadius: '50%', background: '#27ae60',
    color: '#fff', fontSize: '2rem', display: 'flex', alignItems: 'center',
    justifyContent: 'center', margin: '0 auto 20px',
  },
  confirmTitle: { fontSize: '1.6rem', fontWeight: 700, marginBottom: '8px' },
  confirmSub: { color: '#555', marginBottom: '24px' },
  confirmDetail: { background: '#f9f9f9', borderRadius: '10px', padding: '20px', marginBottom: '24px', textAlign: 'left' },
  confirmRow: { display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #eee', fontSize: '0.9rem' },
};

export default Checkout;