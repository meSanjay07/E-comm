import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

function PLP() {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('All');
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8080/api/products')
      .then(res => res.json())
      .then(setProducts)
      .catch(err => console.error('Failed to fetch products:', err));
  }, []);

  const categories = ['All', ...new Set(products.map(p => p.category))];
  const filtered = category === 'All' ? products : products.filter(p => p.category === category);

  return (
    <div style={styles.page}>
      <div style={styles.tabs}>
        {categories.map(cat => (
          <button key={cat} onClick={() => setCategory(cat)}
            style={{ ...styles.tab, ...(category === cat ? styles.activeTab : {}) }}>
            {cat}
          </button>
        ))}
      </div>

      <div style={styles.grid}>
        {filtered.map(product => (
          <div key={product.id} style={styles.card}>
            <img src={product.imageUrl} alt={product.name} style={styles.img} />
            <div style={styles.info}>
              <p style={styles.category}>{product.category}</p>
              <p style={styles.name}>{product.name}</p>
              <p style={styles.price}>${product.price.toFixed(2)}</p>
              <button style={styles.btn} onClick={() => navigate(`/product/${product.id}`)}>
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: { padding: '24px 32px', maxWidth: '1200px', margin: '0 auto' },
  tabs: { display: 'flex', gap: '10px', marginBottom: '28px', flexWrap: 'wrap' },
  tab: {
    padding: '8px 20px', border: '1px solid #ddd', borderRadius: '20px',
    background: '#fff', cursor: 'pointer', fontWeight: 500, fontSize: '0.9rem',
  },
  activeTab: { background: '#1a1a2e', color: '#fff', borderColor: '#1a1a2e' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '24px' },
  card: {
    border: '1px solid #eee', borderRadius: '12px', overflow: 'hidden',
    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
  },
  img: { width: '100%', height: '200px', objectFit: 'cover' },
  info: { padding: '16px' },
  category: { fontSize: '0.75rem', color: '#999', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' },
  name: { fontWeight: 600, fontSize: '0.95rem', marginBottom: '6px' },
  price: { color: '#e94560', fontWeight: 700, fontSize: '1.1rem', marginBottom: '12px' },
  btn: {
    width: '100%', padding: '10px', background: '#1a1a2e', color: '#fff',
    border: 'none', borderRadius: '8px', cursor: 'pointer', fontWeight: 600,
  },
};

export default PLP;
