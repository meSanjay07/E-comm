import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const API = 'http://localhost:8080/api';

function Cart({ refreshCartCount }) {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();

  const loadCart = () =>
    fetch(`${API}/cart`).then(r => r.json()).then(setItems);

  useEffect(() => { loadCart(); }, []);

  const updateQty = (item, delta) => {
    const newQty = item.quantity + delta;
    if (newQty < 1) return removeItem(item.id);
    fetch(`${API}/cart/${item.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...item, quantity: newQty }),
    }).then(() => { loadCart(); refreshCartCount(); });
  };

  const removeItem = (id) => {
    fetch(`${API}/cart/${id}`, { method: 'DELETE' })
      .then(() => { loadCart(); refreshCartCount(); });
  };

  const clearCart = () => {
    fetch(`${API}/cart`, { method: 'DELETE' })
      .then(() => { setItems([]); refreshCartCount(); });
  };

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const shipping = subtotal > 0 ? 9.99 : 0;
  const total = subtotal + shipping;

  if (items.length === 0) return (
    <div style={styles.empty}>
      <p style={{ fontSize: '3rem' }}>🛒</p>
      <p style={{ fontSize: '1.2rem', fontWeight: 600 }}>Your cart is empty</p>
      <button style={styles.btn} onClick={() => navigate('/')}>Continue Shopping</button>
    </div>
  );

  return (
    <div style={styles.page}>
      <h2 style={styles.heading}>Your Cart</h2>
      <div style={styles.layout}>

        {/* Cart Items */}
        <div>
          {items.map(item => (
            <div key={item.id} style={styles.row}>
              <img src={item.imageUrl} alt={item.name} style={styles.img} />
              <div style={styles.info}>
                <p style={styles.name}>{item.name}</p>
                <p style={styles.price}>${item.price.toFixed(2)}</p>
              </div>
              <div style={styles.qtyRow}>
                <button style={styles.qtyBtn} onClick={() => updateQty(item, -1)}>−</button>
                <span style={styles.qty}>{item.quantity}</span>
                <button style={styles.qtyBtn} onClick={() => updateQty(item, +1)}>+</button>
              </div>
              <p style={styles.lineTotal}>${(item.price * item.quantity).toFixed(2)}</p>
              <button style={styles.remove} onClick={() => removeItem(item.id)}>✕</button>
            </div>
          ))}
          <button style={styles.clearBtn} onClick={clearCart}>Clear Cart</button>
        </div>

        {/* Order Summary */}
        <div style={styles.summary}>
          <h3 style={styles.summaryTitle}>Order Summary</h3>
          <div style={styles.summaryRow}><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
          <div style={styles.summaryRow}><span>Shipping</span><span>${shipping.toFixed(2)}</span></div>
          <div style={{ ...styles.summaryRow, ...styles.totalRow }}>
            <span>Total</span><span>${total.toFixed(2)}</span>
          </div>
          <button style={styles.btn} onClick={() => navigate('/checkout')}>
            Proceed to Checkout →
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: { padding: '24px 32px', maxWidth: '1100px', margin: '0 auto' },
  heading: { fontSize: '1.5rem', fontWeight: 700, marginBottom: '24px' },
  empty: { textAlign: 'center', padding: '80px 32px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' },
  layout: { display: 'grid', gridTemplateColumns: '1fr 340px', gap: '32px', alignItems: 'start' },
  row: {
    display: 'flex', alignItems: 'center', gap: '16px',
    padding: '16px 0', borderBottom: '1px solid #eee',
  },
  img: { width: '72px', height: '72px', objectFit: 'cover', borderRadius: '8px' },
  info: { flex: 1 },
  name: { fontWeight: 600, fontSize: '0.9rem', marginBottom: '4px' },
  price: { color: '#888', fontSize: '0.85rem' },
  qtyRow: { display: 'flex', alignItems: 'center', gap: '8px' },
  qtyBtn: {
    width: '28px', height: '28px', border: '1px solid #ddd', borderRadius: '6px',
    background: '#fff', cursor: 'pointer', fontSize: '1rem', fontWeight: 700,
  },
  qty: { minWidth: '24px', textAlign: 'center', fontWeight: 600 },
  lineTotal: { fontWeight: 700, minWidth: '60px', textAlign: 'right' },
  remove: { background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', fontSize: '1rem' },
  clearBtn: {
    marginTop: '16px', background: 'none', border: '1px solid #ddd',
    borderRadius: '8px', padding: '8px 16px', cursor: 'pointer', color: '#888', fontSize: '0.85rem',
  },
  summary: {
    background: '#f9f9f9', border: '1px solid #eee', borderRadius: '12px',
    padding: '24px', display: 'flex', flexDirection: 'column', gap: '12px',
  },
  summaryTitle: { fontWeight: 700, fontSize: '1rem', marginBottom: '4px' },
  summaryRow: { display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: '#555' },
  totalRow: { fontWeight: 700, fontSize: '1rem', color: '#000', borderTop: '1px solid #ddd', paddingTop: '12px', marginTop: '4px' },
  btn: {
    padding: '12px', background: '#1a1a2e', color: '#fff', border: 'none',
    borderRadius: '8px', cursor: 'pointer', fontWeight: 600, fontSize: '0.95rem',
  },
};

export default Cart;